<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Photo Gallery</title>
    <style>
        /* Modal Styles */
        .modal {
            display: none; 
            position: fixed; 
            z-index: 1; 
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto; 
            background-color: rgb(0,0,0); 
            background-color: rgba(0,0,0,0.4); 
        }
        .modal-content {
            background-color: #fefefe;
            margin: 15% auto; 
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
        }
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
        img.thumbnail {
            cursor: pointer;
            width: 100px;
            height: auto;
        }
    </style>
</head>
<body>

<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection details
$servername = "localhost";
$username = "planatir_task_managemen";
$password = "Bishan@1919";
$dbname = "planatir_plan";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
$search_name = '';
if (isset($_POST['search'])) {
    $search_name = $_POST['photo_name'];
}

// SQL query to select records based on the search input
$sql = "SELECT id, photo_name, description, upload_date, photo_type_id FROM photos WHERE photo_name LIKE ?";
$stmt = $conn->prepare($sql);
$search_name_param = "%" . $search_name . "%";
$stmt->bind_param("s", $search_name_param);
$stmt->execute();
$result = $stmt->get_result();

// Display search form
echo '<form method="post" action="">';
echo 'Search for photo: <input type="text" name="photo_name" value="' . htmlspecialchars($search_name) . '">';
echo '<input type="submit" name="search" value="Search">';
echo '</form>';

// Check if there are results
if ($result->num_rows > 0) {
    // Output data of each row
    echo "<table border='1'>";
    echo "<tr><th>ID</th><th>Photo Name</th><th>Description</th><th>Upload Date</th><th>Photo Type ID</th><th>Photo</th></tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["id"] . "</td>";
        echo "<td>" . $row["photo_name"] . "</td>";
        echo "<td>" . $row["description"] . "</td>";
        echo "<td>" . $row["upload_date"] . "</td>";
        echo "<td>" . $row["photo_type_id"] . "</td>";

        // Construct the full path to the image
        $image_path = 'dynamic_investee/uploads/' . htmlspecialchars($row["photo_name"]);
        echo "<td><img src='" . $image_path . "' alt='" . htmlspecialchars($row["photo_name"]) . "' class='thumbnail' onclick='openModal(\"" . $image_path . "\")'></td>";

        echo "</tr>";
    }

    echo "</table>";
} else {
    echo "0 results";
}

// Close connection
$conn->close();
?>

<!-- Modal -->
<div id="myModal" class="modal">
    <span class="close" onclick="closeModal()">&times;</span>
    <div class="modal-content">
        <img id="modalImage" src="" style="width: 100%; height: auto;">
    </div>
</div>

<script>
    function openModal(imageSrc) {
        document.getElementById('modalImage').src = imageSrc;
        document.getElementById('myModal').style.display = "block";
    }

    function closeModal() {
        document.getElementById('myModal').style.display = "none";
    }

    // Close the modal when clicking outside of the modal content
    window.onclick = function(event) {
        if (event.target == document.getElementById('myModal')) {
            closeModal();
        }
    }
</script>

</body>
</html>
