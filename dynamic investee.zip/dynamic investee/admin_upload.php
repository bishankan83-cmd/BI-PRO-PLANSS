<?php

// Display errors for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database connection details
$hostname = "localhost";
$username = "planatir_task_managemen";
$password = "Bishan@1919";
$database = "planatir_plan";

// Create connection
$conn = new mysqli($hostname, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if (isset($_POST['submit'])) {
    // Retrieve and sanitize description
    $description = $conn->real_escape_string($_POST['description']);
    $photoTypeId = intval($_POST['photo_type']);

    // Check if a file was uploaded
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] == UPLOAD_ERR_OK) {
        $photoTmpName = $_FILES['photo']['tmp_name'];
        $photoName = $_FILES['photo']['name'];
        $photoSize = $_FILES['photo']['size'];
        $photoType = $_FILES['photo']['type'];

        // Define allowed file types and max size
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $maxSize = 2 * 1024 * 1024; // 2 MB

        // Check file type and size
        if (in_array($photoType, $allowedTypes) && $photoSize <= $maxSize) {
            // Generate a unique filename
            $uniqueName = uniqid() . "_" . basename($photoName);
            $uploadDir = 'dynamic_investee/uploads/';

            // Ensure the upload directory exists
            if (!is_dir($uploadDir)) {
                if (!mkdir($uploadDir, 0755, true)) {
                    die("Failed to create upload directory.");
                }
            }

            $uploadFile = $uploadDir . $uniqueName;

            // Move the uploaded file to the desired location
            if (move_uploaded_file($photoTmpName, $uploadFile)) {
                // Insert file details into database
                $sql = "INSERT INTO photos (photo_name, description, photo_type_id) VALUES ('$uniqueName', '$description', $photoTypeId)";

                if ($conn->query($sql) === TRUE) {
                    echo "File uploaded and description saved successfully.";
                } else {
                    echo "Database Error: " . $conn->error;
                }
            } else {
                echo "Error moving uploaded file. Debug Info: ";
                echo "Temporary name: " . htmlspecialchars($photoTmpName) . "<br>";
                echo "Destination: " . htmlspecialchars($uploadFile) . "<br>";
            }
        } else {
            echo "Invalid file type or size.";
        }
    } else {
        echo "No file uploaded or upload error. Error code: " . $_FILES['photo']['error'];
    }
}

$conn->close();
?>
