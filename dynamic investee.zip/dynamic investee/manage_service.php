<?php
$servername = "localhost";
$username = "planatir_task_managemen";
$password = "Bishan@1919";
$dbname = "planatir_task_managemen";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['serviceId'];
    $title = $_POST['serviceTitle'];
    $image = $_POST['serviceImage'];
    $description = $_POST['serviceDescription'];

    if (empty($id)) {
        $sql = "INSERT INTO services (title, image, description) VALUES ('$title', '$image', '$description')";
    } else {
        $sql = "UPDATE services SET title='$title', image='$image', description='$description' WHERE id='$id'";
    }

    if ($conn->query($sql) === TRUE) {
        echo "Service saved successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
