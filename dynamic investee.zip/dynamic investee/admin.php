<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Photo Upload</title>
</head>
<body>
    <h1>Upload Photo with Description</h1>
    <form action="admin_upload.php" method="post" enctype="multipart/form-data">
        <label for="photo">Choose Photo:</label>
        <input type="file" name="photo" id="photo" required><br><br>

        <label for="description">Description:</label><br>
        <textarea name="description" id="description" rows="4" cols="50" required></textarea><br><br>

        <label for="photo_type">Photo Type:</label>
        <select name="photo_type" id="photo_type">
            <?php
            // Database connection details
            $hostname = "localhost";
            $username = "planatir_task_managemen";
            $password = "Bishan@1919";
            $database = "planatir_plan";

            // Create connection
            $conn = new mysqli($hostname, $username, $password, $database);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Fetch photo types from the database
            $result = $conn->query("SELECT id, type_name FROM photo_types");

            if ($result->num_rows > 0) {
                // Output data of each row
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . htmlspecialchars($row['id']) . "'>" . htmlspecialchars($row['type_name']) . "</option>";
                }
            } else {
                echo "<option value=''>No photo types available</option>";
            }

            $conn->close();
            ?>
        </select><br><br>

        <input type="submit" name="submit" value="Upload">
    </form>
</body>
</html>
