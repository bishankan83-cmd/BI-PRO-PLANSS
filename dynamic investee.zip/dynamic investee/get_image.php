<?php
// Database connection
$servername = "localhost";
$username = "planatir_task_managemen";
$password = "Bishan@1919";
$database = "planatir_atire";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get image ID from URL parameter
$image_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch image from database
$sql = "SELECT image FROM images WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $image_id);
$stmt->execute();
$stmt->bind_result($image);
$stmt->fetch();
$stmt->close();
$conn->close();

// Output image
header("Content-Type: image/png"); // Adjust according to your image type
echo $image;
?>
