<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .admin-panel {
            margin: 20px;
        }
        .admin-panel .nav-item {
            cursor: pointer;
        }
        .form-section, .list-section {
            display: none;
        }
        .form-section.active, .list-section.active {
            display: block;
        }
    </style>
</head>
<body>
    <div class="container admin-panel">
        <h2 class="text-center mb-4">Admin Panel</h2>
        <ul class="nav nav-tabs">
            <li class="nav-item">
                <a class="nav-link active" data-toggle="tab" href="#services">Manage Services</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#features">Manage Features</a>
            </li>
        </ul>
        <div class="tab-content">
            <!-- Services Tab -->
            <div id="services" class="tab-pane fade show active">
                <div class="form-section active" id="service-form">
                    <h4 class="mb-4">Add/Update Service</h4>
                    <form action="manage_services.php" method="post">
                        <input type="hidden" id="serviceId" name="serviceId">
                        <div class="form-group">
                            <label for="serviceTitle">Service Title</label>
                            <input type="text" class="form-control" id="serviceTitle" name="serviceTitle" required>
                        </div>
                        <div class="form-group">
                            <label for="serviceImage">Service Image (URL)</label>
                            <input type="text" class="form-control" id="serviceImage" name="serviceImage" required>
                        </div>
                        <div class="form-group">
                            <label for="serviceDescription">Service Description</label>
                            <textarea class="form-control" id="serviceDescription" name="serviceDescription" rows="4" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </form>
                </div>
                <div class="list-section" id="service-list">
                    <h4 class="mb-4">Services List</h4>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Description</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="serviceTableBody">
                            <!-- Service rows will be inserted here by JS -->
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Features Tab -->
            <div id="features" class="tab-pane fade">
                <div class="form-section active" id="feature-form">
                    <h4 class="mb-4">Add/Update Feature</h4>
                    <form action="manage_features.php" method="post">
                        <input type="hidden" id="featureId" name="featureId">
                        <div class="form-group">
                            <label for="featureTitle">Feature Title</label>
                            <input type="text" class="form-control" id="featureTitle" name="featureTitle" required>
                        </div>
                        <div class="form-group">
                            <label for="featureIcon">Feature Icon (Font Awesome class)</label>
                            <input type="text" class="form-control" id="featureIcon" name="featureIcon" required>
                        </div>
                        <div class="form-group">
                            <label for="featureDescription">Feature Description</label>
                            <textarea class="form-control" id="featureDescription" name="featureDescription" rows="4" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </form>
                </div>
                <div class="list-section" id="feature-list">
                    <h4 class="mb-4">Features List</h4>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Description</th>
                                <th>Icon</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="featureTableBody">
                            <!-- Feature rows will be inserted here by JS -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.nav-link').click(function() {
                $('.nav-link').removeClass('active');
                $(this).addClass('active');
                var target = $(this).attr('href');
                $('.tab-pane').removeClass('show active');
                $(target).addClass('show active');
            });

            // Function to load services and features from the database
            function loadTableData(url, tableBodyId) {
                $.get(url, function(data) {
                    $(tableBodyId).html(data);
                });
            }

            loadTableData('fetch_services.php', '#serviceTableBody');
            loadTableData('fetch_features.php', '#featureTableBody');
        });

        function editItem(type, id) {
            $.get('fetch_' + type + '.php', {id: id}, function(data) {
                var item = JSON.parse(data);
                $('#' + type + 'Id').val(item.id);
                $('#' + type + 'Title').val(item.title);
                $('#' + type + 'Description').val(item.description);
                if (type === 'service') {
                    $('#' + type + 'Image').val(item.image);
                } else {
                    $('#' + type + 'Icon').val(item.icon);
                }
                $('.form-section').removeClass('active');
                $('#' + type + '-form').addClass('active');
            });
        }

        function deleteItem(type, id) {
            if (confirm('Are you sure you want to delete this ' + type + '?')) {
                $.post('delete_' + type + '.php', {id: id}, function(response) {
                    alert(response);
                    loadTableData('fetch_' + type + '.php', '#'+type+'TableBody');
                });
            }
        }
    </script>
</body>
</html>
