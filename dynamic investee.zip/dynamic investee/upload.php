<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if the file was uploaded without errors
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $fileTmpPath = $_FILES['image']['tmp_name'];
        $fileName = $_FILES['image']['name'];
        $fileSize = $_FILES['image']['size'];
        $fileType = $_FILES['image']['type'];
        $fileNameCmps = explode('.', $fileName);
        $fileExtension = strtolower(end($fileNameCmps));

        // Define allowed file extensions
        $allowedExts = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($fileExtension, $allowedExts)) {
            // Directory where the file will be saved
            $uploadDir = 'uploads/';
            
            // Create the directory if it does not exist
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0755, true);
            }

            // Path where the file will be saved
            $dest_path = $uploadDir . $fileName;

            // Move the uploaded file to the destination directory
            if (move_uploaded_file($fileTmpPath, $dest_path)) {
                echo "File is successfully uploaded.";
            } else {
                echo "There was an error uploading the file, please try again!";
            }
        } else {
            echo "Upload failed. Allowed file types: jpg, jpeg, png, gif.";
        }
    } else {
        echo "No file uploaded or there was an upload error.";
    }
} else {
    echo "Invalid request method.";
}
?>
