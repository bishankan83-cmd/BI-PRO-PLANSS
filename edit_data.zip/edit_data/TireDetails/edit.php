<?php
include 'db.php';
include 'templates/header.php';

$icode = $_GET['icode'];
$result = $conn->query("SELECT * FROM tire_details WHERE icode = $icode");
$item = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $icode = $_POST['icode'];
    $Description = $_POST['Description'];
    $Brand = $_POST['Brand'];
    $Type = $_POST['Type'];
    $Spec = $_POST['Spec'];
    $Colour = $_POST['Colour'];
    $Rim = !empty($_POST['Rim']) ? $_POST['Rim'] : null;
    $greenweight = !empty($_POST['greenweight']) ? $_POST['greenweight'] : null;
    $stgreenweight = $_POST['stgreenweight'];

    $stmt = $conn->prepare("UPDATE tire_details SET icode = ?, Description = ?, Brand = ?, Type = ?, Spec = ?, Colour = ?, Rim = ?, greenweight = ?, stgreenweight = ? WHERE icode = ?");
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param('sssssssssi', $icode, $Description, $Brand, $Type, $Spec, $Colour, $Rim, $greenweight, $stgreenweight, $icode);
    if (!$stmt->execute()) {
        die("Execution failed: " . $stmt->error);
    }

    header('Location: index.php');
}
?>



<form method="POST" style="max-width: 1200px; margin: 0 auto; padding: 50px; background-color: #f9f9f9; border: 1px solid #ddd; border-radius: 8px;">
    <label for="icode" style="font-weight: bold; margin-bottom: 5px;">I code:</label>
    <input type="text" name="icode" id="icode"  style="width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px;"><br>

    <label for="Description" style="font-weight: bold; margin-bottom: 5px;">Description:</label>
    <input type="text" name="Description" id="Description" style="width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px;"><br>

    <label for="Brand" style="font-weight: bold; margin-bottom: 5px;">Brand:</label>
    <input type="number" name="Brand" id="Brand" style="width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px;"><br>

    <label for="Type" style="font-weight: bold; margin-bottom: 5px;">Type:</label>
    <input type="text" name="Type" id="Type" style="width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px;"><br>

    <label for="Spec" style="font-weight: bold; margin-bottom: 5px;">Spec:</label>
    <input type="text" name="Spec" id="Spec" style="width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px;"><br>

    <label for="Colour" style="font-weight: bold; margin-bottom: 5px;">Colour:</label>
    <input type="text" name="Colour" id="Colour" style="width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px;"><br>

    <label for="Rim" style="font-weight: bold; margin-bottom: 5px;">Rim:</label>
<input type="number" name="Rim" id="Rim" style="width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px;"><br>


<label for="greenweight" style="font-weight: bold; margin-bottom: 5px;">greenweight:</label>
<input type="number" name="greenweight" id="greenweight" style="width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px;"><br>


<label for="stgreenweight" style="font-weight: bold; margin-bottom: 5px;">stgreenweight:</label>
    <input type="text" name="stgreenweight" id="stgreenweight" style="width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px;"><br>
<br></br>
<div style="display: flex; justify-content: flex-end;">
    <button type="submit" style="padding: 10px 100px; background-color: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer;">
        Update
    </button>
</div>
</form>