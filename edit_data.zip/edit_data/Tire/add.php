<?php
include 'db.php';
include 'templates/header.php';


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $icode = $_POST['icode'];
    $description = $_POST['description'];
    $time_taken = $_POST['time_taken'];
    $is_available = $_POST['is_available'];
    $availability_date = $_POST['availability_date'];
    $cuing_group_id = $_POST['cuing_group_id'];
    $cuing_group_name = $_POST['cuing_group_name'];

    $stmt = $conn->prepare("INSERT INTO stock (icode, description, time_taken, is_available, availability_date, cuing_group_id, cuing_group_name) VALUES (?, ?, ?, ?, ?, ?, ?)");

    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param('sisiiii', $icode, $description, $time_taken, $is_available, $availability_date, $cuing_group_id, $cuing_group_name);

    if ($stmt->execute()) {
        echo '<p style=" color: #28a745; text-align: center;">Data inserted successfully.</p>';
    
    
    } else {
        echo "Error inserting data: " . $stmt->error;
    }

}
?>

<form method="POST" style="max-width: 1200px; margin: 0 auto; padding: 50px; background-color: #f9f9f9; border: 1px solid #ddd; border-radius: 8px;">
    <label for="icode" style="font-weight: bold; margin-bottom: 5px;">I code:</label>
    <input type="text" name="icode" id="icode" required style="width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px;"><br>

    <label for="description" style="font-weight: bold; margin-bottom: 5px;">Description:</label>
    <input type="text" name="description" id="description" required style="width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px;"><br>

    <label for="time_taken" style="font-weight: bold; margin-bottom: 5px;">Time taken:</label>
    <input type="text" name="time_taken" id="time_taken" required style="width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px;"><br>

    <label for="is_available" style="font-weight: bold; margin-bottom: 5px;">Is available:</label>
    <input type="text" name="is_available" id="is_available" required style="width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px;"><br>

    <label for="availability_date" style="font-weight: bold; margin-bottom: 5px;">Availability date:</label>
    <input type="text" name="availability_date" id="availability_date" required style="width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px;"><br>

    <label for="cuing_group_id" style="font-weight: bold; margin-bottom: 5px;">Cuing group id:</label>
    <input type="text" name="cuing_group_id" id="cuing_group_id" required style="width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px;"><br>

    <label for="cuing_group_name" style="font-weight: bold; margin-bottom: 5px;">Cuing group name:</label>
    <input type="text" name="cuing_group_name" id="cuing_group_name" required style="width: 100%; padding: 10px; margin-bottom: 15px; border: 1px solid #ccc; border-radius: 4px;"><br>
<br></br>
<div style="display: flex; justify-content: flex-end;">
    <button type="submit" style="padding: 10px 100px; background-color: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer;">
        Add
    </button>
</div>
</form>
