<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quality Measurement Data Entering System</title>
    <link href="https://fonts.googleapis.com/css2?family=Cantarell:wght@400;700&family=Open+Sans:wght@400;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Open Sans', sans-serif;
            background-color: #f0f0f0;
            color: #000000;
            line-height: 1.6;
        }
        
        .container {
            margin: 0 auto;
            max-width: 1200px;
            padding: 20px;
            background-color: #f0f0f0;
        }
        
        .main-card {
            border-radius: 15px;
            border: 2px solid #F28018;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
            margin-bottom: 30px;
            overflow: hidden;
        }
        
        .main-header {
            background-color: #343a40;
            color: #ffffff;
            font-size: 24px;
            font-weight: bold;
            text-align: center;
            border-bottom: 2px solid #F28018;
            padding: 20px;
            font-family: 'Cantarell', sans-serif;
        }
        
        .main-body {
            padding: 30px;
            background-color: #ffffff;
        }
        
        .menu-title {
            font-family: 'Cantarell', sans-serif;
            font-weight: bold;
            font-size: 20px;
            margin-bottom: 25px;
            color: #343a40;
            text-align: center;
            border-bottom: 2px solid #F28018;
            padding-bottom: 10px;
        }
        
        .button-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .nav-button {
            background-color: #000000;
            color: #FFFFFF;
            border: none;
            border-radius: 40px;
            padding: 15px 20px;
            font-size: 15px;
            text-decoration: none;
            text-align: center;
            transition: all 0.3s ease;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 70px;
            font-family: 'Cantarell', sans-serif;
            font-weight: regular;
            cursor: pointer;
        }
        
        .nav-button:hover {
            background-color: #333333;
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        
        .search-section {
            margin: 30px 0;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 15px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border: 1px solid #F28018;
        }
        
        .search-form {
            display: flex;
            justify-content: center;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            margin: 10px;
        }
        
        .search-form input[type="text"] {
            padding: 12px;
            width: 280px;
            border: 1px solid #CCCCCC;
            border-radius: 40px;
            font-family: 'Cantarell', sans-serif;
            font-weight: regular;
        }
        
        .search-form button {
            background-color: #000000;
            color: #FFFFFF;
            padding: 12px 25px;
            border: none;
            border-radius: 40px;
            cursor: pointer;
            font-family: 'Cantarell', sans-serif;
            transition: background-color 0.3s;
        }
        
        .search-form button:hover {
            background-color: #333333;
        }
        
        .select-container {
            margin: 15px;
            text-align: center;
            display: flex;
            justify-content: center;
            gap: 20px;
            flex-wrap: wrap;
        }
        
        select {
            padding: 12px;
            border: 1px solid #CCCCCC;
            border-radius: 40px;
            font-family: 'Cantarell', sans-serif;
            font-weight: regular;
            min-width: 200px;
        }
        
        .highlight-message {
            font-size: 16px;
            color: #ffffff;
            background-color: #000000;
            padding: 15px;
            border-radius: 8px;
            text-align: center;
            font-weight: bold;
            margin-top: 20px;
            border: 2px solid #F28018;
            animation: blink 10s infinite;
        }
        
        @keyframes blink {
            0% { opacity: 1; }
            50% { opacity: 0.7; }
            100% { opacity: 1; }
        }
        
        .stockr-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        
        .stockr-table th {
            background-color: #F28018;
            color: #000000;
            font-family: 'Cantarell', sans-serif;
            font-weight: bold;
            position: sticky;
            top: 0;
            z-index: 100;
            padding: 15px;
            text-align: left;
        }
        
        .stockr-table td {
            border: 1px solid #CCCCCC;
            padding: 12px;
            text-align: left;
            font-family: 'Open Sans', sans-serif;
            background-color: #ffffff;
        }
        
        .stockr-table tr:hover td {
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="main-card">
            <div class="main-header">
                QUALITY MEASUREMENT DATA ENTERING SYSTEM
            </div>
            <div class="main-body">
                <div class="menu-title">NAVIGATION MENU</div>
                
                <div class="button-grid">
                    <a href="daily_defect.php" class="nav-button">Daily Defect BLACK</a>
                    <a href="daily_defect_nm.php" class="nav-button">Daily POB Tyres Grinding Book Data Entry</a>
                    <a href="pro_serial_final.php" class="nav-button">Final Inspection - POB</a>
                    <a href="f_us_hard.php" class="nav-button">US & HARDNESS SHEET OF FINISH TYRE RESILENT, POB (BLACK / NY)</a>
                    <a href="green_tire.php" class="nav-button">Green Tire</a>
                    <a href="daily_defect_nm_nm.php" class="nav-button">Daily Defect NM</a>
                    <a href="curing_section.php" class="nav-button">Curing Section</a>
                </div>
                
                <div class="search-section">
                    <div class="select-container">
                        <select name="category">
                            <option value="">Select Category</option>
                            <option value="tyre">Tyre</option>
                            <option value="process">Process</option>
                            <option value="defect">Defect</option>
                        </select>
                        
                        <select name="timeframe">
                            <option value="">Select Timeframe</option>
                            <option value="today">Today</option>
                            <option value="week">This Week</option>
                            <option value="month">This Month</option>
                        </select>
                    </div>
                    
                    <div class="search-form">
                        <input type="text" placeholder="Search records...">
                        <button type="submit">Search</button>
                    </div>
                </div>
                
                <div class="highlight-message">
                    TODAY'S PENDING MEASUREMENTS: 12 | COMPLETED: 48
                </div>
            </div>
        </div>
        
        <!-- Example of a data table that might be shown -->
        <div class="main-card">
            <div class="main-header" style="font-size: 20px;">
                RECENT QUALITY MEASUREMENTS
            </div>
            <div class="main-body">
                <table class="stockr-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Date</th>
                            <th>Type</th>
                            <th>Measurement</th>
                            <th>Operator</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>QM001</td>
                            <td>16-05-2025</td>
                            <td>POB Black</td>
                            <td>Hardness: 65</td>
                            <td>Operator A</td>
                            <td>Completed</td>
                        </tr>
                        <tr>
                            <td>QM002</td>
                            <td>16-05-2025</td>
                            <td>Green Tire</td>
                            <td>Thickness: 12.5mm</td>
                            <td>Operator B</td>
                            <td>Completed</td>
                        </tr>
                        <tr>
                            <td>QM003</td>
                            <td>16-05-2025</td>
                            <td>Curing</td>
                            <td>Temperature: 180°C</td>
                            <td>Operator C</td>
                            <td>Pending</td>
                        </tr>
                        <tr>
                            <td>QM004</td>
                            <td>15-05-2025</td>
                            <td>POB NY</td>
                            <td>Resilience: 92%</td>
                            <td>Operator D</td>
                            <td>Completed</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>