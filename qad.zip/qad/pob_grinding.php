<?php
// Database connection configuration
$servername = "localhost";
$username = "planatir_task_managemen"; 
$password = "Bishan@1919"; 
$dbname = "planatir_task_managemen";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$serialNumber = "";
$size = "";
$brand = "";
$type = "";
$color = "";
$description = ""; // New field for description
$gaugeOk = "";
$gaugeCenter = "";
$gaugeEdge = "";
$defect = "";
$searchError = "";
$successMessage = "";
$errorMessage = "";

// Get all available serial numbers from tire_data table
$serialNumbers = array();
$serialNumberQuery = "SELECT serialNumber FROM tire_data";
$serialNumberResult = $conn->query($serialNumberQuery);
if ($serialNumberResult && $serialNumberResult->num_rows > 0) {
    while($row = $serialNumberResult->fetch_assoc()) {
        $serialNumbers[] = $row['serialNumber'];
    }
}

// Also get serial numbers from tire_grinding_data table if they don't already exist in the array
$grindingSerialQuery = "SELECT SIR_NO FROM tire_grinding_data";
$grindingSerialResult = $conn->query($grindingSerialQuery);
if ($grindingSerialResult && $grindingSerialResult->num_rows > 0) {
    while($row = $grindingSerialResult->fetch_assoc()) {
        if (!in_array($row['SIR_NO'], $serialNumbers)) {
            $serialNumbers[] = $row['SIR_NO'];
        }
    }
}

// Process search form
if (isset($_POST['search'])) {
    $serialNumber = $_POST['serial_number'];
    
    // Validate serial number
    if (empty($serialNumber)) {
        $searchError = "Please enter a serial number";
    } else {
        // First check if serial exists in tire_grinding_data table
        $checkGrindingData = "SELECT * FROM tire_grinding_data WHERE SIR_NO = ?";
        $stmtCheck = $conn->prepare($checkGrindingData);
        $stmtCheck->bind_param("s", $serialNumber);
        $stmtCheck->execute();
        $resultCheck = $stmtCheck->get_result();
        
        if ($resultCheck->num_rows > 0) {
            $searchError = "This serial number already exists in the grinding records.";
        } else {
            // Then check if we can find this serial in tire_data
            $sql = "SELECT td.*, tt.type, tt.Colour, tt.description 
                   FROM tire_data td 
                   LEFT JOIN tire_details tt ON td.tireCode = tt.icode 
                   WHERE td.serialNumber = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $serialNumber);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                // We found the tire in the master data, pre-fill the form
                $row = $result->fetch_assoc();
                $size = $row['tireCode']; // Using tireCode as size
                $brand = $row['brand'];
                // Get additional fields from tire_details if available
                $type = isset($row['type']) ? $row['type'] : "";
                $color = isset($row['color']) ? $row['color'] : "";
                $description = isset($row['description']) ? $row['description'] : "";
                $defect = ""; // Default to empty for user input
            } else {
                // If record doesn't exist in either table, pre-fill the form with empty values for a new record
                $size = "";
                $brand = "";
                $type = "";
                $color = "";
                $description = "";
                $defect = "";
            }
            $stmt->close();
        }
        $stmtCheck->close();
    }
}

// Process record submission
if (isset($_POST['submit'])) {
    // Get form data
    $serialNumber = $_POST['serial_number'];
    $size = $_POST['size'];
    $brand = $_POST['brand'];
    $type = $_POST['type'];
    $color = $_POST['color'];
    $description = $_POST['description']; // Get description from form
    $gaugeOk = isset($_POST['gauge_ok']) ? 1 : 0;
    $gaugeCenter = isset($_POST['gauge_center']) ? 1 : 0;
    $gaugeEdge = isset($_POST['gauge_edge']) ? 1 : 0;
    $defect = $_POST['defect'];
    $operator = $_POST['operator'];
    
    // Validate form data
    $formValid = true;
    
    // Validate serial number
    if (empty($serialNumber)) {
        $errorMessage = "Serial number is required.";
        $formValid = false;
    }
    
    // Validate operator field
    if (empty($operator)) {
        $errorMessage = "Operator field is required.";
        $formValid = false;
    }
    
    // If form is valid, insert the record
    if ($formValid) {
        // Check if table exists, if not create it
        $tableCheck = $conn->query("SHOW TABLES LIKE 'tire_grinding_data'");
        if ($tableCheck->num_rows == 0) {
            // Table doesn't exist, create it
            $createTable = "CREATE TABLE tire_grinding_data (
                id INT(11) AUTO_INCREMENT PRIMARY KEY,
                entry_date DATE DEFAULT CURRENT_DATE,
                SIR_NO VARCHAR(50) NOT NULL,
                size VARCHAR(50),
                brand VARCHAR(50),
                type VARCHAR(50),
                color VARCHAR(50),
                description VARCHAR(255), -- Added description field
                gauge_ok TINYINT(1) DEFAULT 0,
                gauge_center TINYINT(1) DEFAULT 0,
                gauge_edge TINYINT(1) DEFAULT 0,
                defect VARCHAR(100),
                operator VARCHAR(100),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )";
            
            if ($conn->query($createTable) !== TRUE) {
                $errorMessage = "Error creating table: " . $conn->error;
                $formValid = false;
            }
        } else {
            // Check if description column exists, if not add it
            $columnCheck = $conn->query("SHOW COLUMNS FROM tire_grinding_data LIKE 'description'");
            if ($columnCheck->num_rows == 0) {
                $alterTable = "ALTER TABLE tire_grinding_data ADD COLUMN description VARCHAR(255) AFTER color";
                $conn->query($alterTable);
            }
        }
        
        if ($formValid) {
            $sql = "INSERT INTO tire_grinding_data (SIR_NO, size, brand, type, color, description, gauge_ok, gauge_center, gauge_edge, defect, operator) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssssiiiis", 
                $serialNumber, $size, $brand, $type, $color, $description,
                $gaugeOk, $gaugeCenter, $gaugeEdge, $defect, $operator);
            
            if ($stmt->execute()) {
                $successMessage = "Tire grinding record successfully added!";
                // Add the new serial number to our array for the dropdown
                if (!in_array($serialNumber, $serialNumbers)) {
                    $serialNumbers[] = $serialNumber;
                }
                // Reset form data
                $serialNumber = "";
                $size = "";
                $brand = "";
                $type = "";
                $color = "";
                $description = "";
                $gaugeOk = "";
                $gaugeCenter = "";
                $gaugeEdge = "";
                $defect = "";
            } else {
                $errorMessage = "Error: " . $stmt->error;
            }
            
            $stmt->close();
        }
    }
}

// New function to fetch tire data via AJAX
if (isset($_GET['fetch_tire_data']) && !empty($_GET['serial'])) {
    $serial = $_GET['serial'];
    
    // Enhanced query to join tire_data with tire_details table
    $sql = "SELECT td.*, tt.type, tt.color, tt.description 
           FROM tire_data td 
           LEFT JOIN tire_details tt ON td.tireCode = tt.icode
           WHERE td.serialNumber = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $serial);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $response = [
            'success' => true,
            'data' => [
                'size' => $row['tireCode'],
                'brand' => $row['brand'],
                'weight' => $row['tireWeight'],
                'press' => $row['pressNumber'],
                'type' => isset($row['type']) ? $row['type'] : '',
                'color' => isset($row['color']) ? $row['color'] : '',
                'description' => isset($row['description']) ? $row['description'] : ''
            ]
        ];
    } else {
        $response = [
            'success' => false,
            'message' => 'Tire data not found'
        ];
    }
    
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tire Grinding Data Entry - ATIRE Quality System</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-rc.0/css/select2.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f5f5f5;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .navbar-brand img {
            height: 40px;
            margin-right: 10px;
        }
        .card {
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .card-header {
            background-color: #343a40;
            color: white;
            font-weight: bold;
        }
        .form-control:disabled, .form-control[readonly] {
            background-color: #e9ecef;
            cursor: not-allowed;
        }
        .required-field::after {
            content: " *";
            color: red;
        }
        /* Select2 custom styling */
        .select2-container--default .select2-selection--single {
            height: 38px;
            border: 1px solid #ced4da;
            border-radius: 0.25rem;
        }
        .select2-container--default .select2-selection--single .select2-selection__rendered {
            line-height: 38px;
            padding-left: 12px;
        }
        .select2-container--default .select2-selection--single .select2-selection__arrow {
            height: 36px;
        }
        /* Data source badge */
        .data-source-badge {
            font-size: 0.8rem;
            padding: 3px 8px;
            margin-left: 10px;
        }
        /* Refresh icon animation */
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        .spinning {
            animation: spin 1s linear infinite;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="#">
                ATIRE Quality System
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="#">Grinding Data Entry</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="view_grinding_records.php">View Records</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="quality_data_entry.php">Quality Data Entry</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container py-4">
        <h2 class="mb-4">Daily POB Tyres Grinding Book Data Entry</h2>
        
        <?php if (!empty($successMessage)): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $successMessage; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        
        <?php if (!empty($errorMessage)): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $errorMessage; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Search Tire Serial Number</h5>
            </div>
            <div class="card-body">
                <form method="post" action="" id="search-form">
                    <div class="row mb-3">
                        <div class="col-md-8">
                            <label for="serial_number" class="form-label required-field">Serial Number (SIR NO)</label>
                            <div class="input-group">
                                <select class="form-select select2" id="serial_number" name="serial_number" required>
                                    <option value="">Enter or Select a Serial Number</option>
                                    <?php foreach($serialNumbers as $sn): ?>
                                    <option value="<?php echo htmlspecialchars($sn); ?>" <?php echo ($sn === $serialNumber) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($sn); ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                                <button type="button" class="btn btn-outline-secondary" id="fetch-data-btn" title="Fetch data from master database">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-repeat" viewBox="0 0 16 16">
                                        <path d="M11.534 7h3.932a.25.25 0 0 1 .192.41l-1.966 2.36a.25.25 0 0 1-.384 0l-1.966-2.36a.25.25 0 0 1 .192-.41zm-11 2h3.932a.25.25 0 0 0 .192-.41L2.692 6.23a.25.25 0 0 0-.384 0L.342 8.59A.25.25 0 0 0 .534 9z"/>
                                        <path fill-rule="evenodd" d="M8 3c-1.552 0-2.94.707-3.857 1.818a.5.5 0 1 1-.771-.636A6.002 6.002 0 0 1 13.917 7H12.9A5.002 5.002 0 0 0 8 3zM3.1 9a5.002 5.002 0 0 0 8.757 2.182.5.5 0 1 1 .771.636A6.002 6.002 0 0 1 2.083 9H3.1z"/>
                                    </svg>
                                </button>
                            </div>
                            <div id="data-source-indicator" class="mt-1"></div>
                            <?php if (!empty($searchError)): ?>
                                <div class="text-danger mt-1"><?php echo htmlspecialchars($searchError); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-4 d-flex align-items-end">
                            <button type="submit" name="search" class="btn btn-primary">
                                Search
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        
        <?php if (empty($searchError) || (isset($_POST['search']) && empty($serialNumber))): ?>
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Tire Grinding Data Form</h5>
            </div>
            <div class="card-body">
                <form method="post" action="" id="grinding-form">
                    <input type="hidden" name="serial_number" id="form-serial-number" value="<?php echo htmlspecialchars($serialNumber); ?>">
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="size" class="form-label">Tire Code</label>
                            <input type="text" class="form-control" id="size" name="size" value="<?php echo htmlspecialchars($size); ?>">
                        </div>
                        <div class="col-md-6">
                            <label for="brand" class="form-label">Brand</label>
                            <input type="text" class="form-control" id="brand" name="brand" value="<?php echo htmlspecialchars($brand); ?>">
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label for="type" class="form-label">Type</label>
                            <input type="text" class="form-control" id="type" name="type" value="<?php echo htmlspecialchars($type); ?>">
                        </div>
                        <div class="col-md-4">
                            <label for="color" class="form-label">Color</label>
                            <input type="text" class="form-control" id="color" name="color" value="<?php echo htmlspecialchars($color); ?>">
                        </div>
                        <div class="col-md-4">
                            <label for="description" class="form-label">Description</label>
                            <input type="text" class="form-control" id="description" name="description" value="<?php echo htmlspecialchars($description); ?>">
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label for="defect" class="form-label">Defect</label>
                            <input type="text" class="form-control" id="defect" name="defect" value="<?php echo htmlspecialchars($defect); ?>">
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="gauge_ok" name="gauge_ok" value="1" <?php echo $gaugeOk ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="gauge_ok">
                                    Gauge - OK
                                </label>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="gauge_center" name="gauge_center" value="1" <?php echo $gaugeCenter ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="gauge_center">
                                    Gauge - Center
                                </label>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="gauge_edge" name="gauge_edge" value="1" <?php echo $gaugeEdge ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="gauge_edge">
                                    Gauge - Edge
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Additional fields to display when data is fetched from tire_data -->
                    <div id="additional-data" class="row mb-3" style="display: none;">
                        <div class="col-12">
                            <div class="card bg-light">
                                <div class="card-header bg-info text-white">
                                    Additional Tire Information
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <label class="form-label">Tire Weight</label>
                                            <p class="form-control-plaintext border rounded px-2" id="tire-weight">-</p>
                                        </div>
                                        <div class="col-md-6">
                                            <label class="form-label">Press Number</label>
                                            <p class="form-control-plaintext border rounded px-2" id="press-number">-</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="operator" class="form-label required-field">Operator/Checked By</label>
                            <input type="text" class="form-control" id="operator" name="operator" required>
                        </div>
                    </div>
                    
                    <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <button type="reset" class="btn btn-secondary me-md-2">Reset</button>
                        <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <footer class="bg-dark text-white text-center py-3 mt-5">
        <div class="container">
            <p class="mb-0">© 2024 ATIRE Quality System. All rights reserved.</p>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-rc.0/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            // Initialize Select2 for serial number dropdown
            $('.select2').select2({
                tags: true,
                createTag: function (params) {
                    return {
                        id: params.term,
                        text: params.term,
                        newTag: true
                    }
                }
            });
            
            // Update hidden form field when select2 changes
            $('#serial_number').on('change', function() {
                $('#form-serial-number').val($(this).val());
            });
            
            // Fetch tire data button click handler
            $('#fetch-data-btn').on('click', function() {
                const serialNumber = $('#serial_number').val();
                if (!serialNumber) {
                    alert('Please enter a serial number first');
                    return;
                }
                
                // Add spinning animation to the icon
                const icon = $(this).find('svg');
                icon.addClass('spinning');
                
                // Make AJAX request to get tire data
                $.ajax({
                    url: '?fetch_tire_data=1',
                    data: { serial: serialNumber },
                    method: 'GET',
                    dataType: 'json',
                    success: function(response) {
                        icon.removeClass('spinning');
                        
                        if (response.success) {
                            // Update form fields with data
                            $('#size').val(response.data.size);
                            $('#brand').val(response.data.brand);
                            $('#type').val(response.data.type);
                            $('#color').val(response.data.color);
                            $('#description').val(response.data.description);
                            
                            // Show additional data
                            $('#tire-weight').text(response.data.weight || 'N/A');
                            $('#press-number').text(response.data.press || 'N/A');
                            $('#additional-data').show();
                            
                            // Add data source badge
                            $('#data-source-indicator').html('<span class="badge bg-success data-source-badge">Data loaded from master database</span>');
                        } else {
                            // Clear form fields as needed
                            $('#size').val('');
                            $('#brand').val('');
                            $('#type').val('');
                            $('#color').val('');
                            $('#description').val('');
                            $('#additional-data').hide();
                            
                            // Add data source badge
                            $('#data-source-indicator').html('<span class="badge bg-warning text-dark data-source-badge">Serial number not found in master database</span>');
                        }
                    },
                    error: function() {
                        icon.removeClass('spinning');
                        alert('Error fetching tire data. Please try again.');
                        $('#data-source-indicator').html('<span class="badge bg-danger data-source-badge">Error loading data</span>');
                    }
                });
            });
            
            // Form validation
            $('#grinding-form').on('submit', function(e) {
                const serialNumber = $('#form-serial-number').val();
                const operator = $('#operator').val();
                
                if (!serialNumber) {
                    e.preventDefault();
                    alert('Please enter a serial number');
                    return false;
                }
                
                if (!operator) {
                    e.preventDefault();
                    alert('Please enter operator name');
                    return false;
                }
                
                return true;
            });
        });
    </script>
</body>
</html>