<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start session to store success message
session_start();



// Database connection
$servername = "localhost";
$username = "planatir_task_managemen";
$password = "Bishan@1919";
$dbname = "planatir_task_managemen";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_inspection'])) {
    $date = $conn->real_escape_string($_POST['date']);
    $shift_time = $conn->real_escape_string($_POST['shift_time']);
    $employee_id = $conn->real_escape_string($_POST['employee_id']);
    $serialNumbers = $_POST['serialNumber'] ?? [];
    $tyre_sizes = $_POST['tyre_size'] ?? [];
    $brands = $_POST['brand'] ?? [];
    $m_no_1s = $_POST['m_no_1'] ?? [];
    $temps = $_POST['temp'] ?? [];
    $width_1s = $_POST['width_1'] ?? [];
    $diams = $_POST['diam'] ?? [];
    $end_time_1s = $_POST['end_time_1'] ?? [];
    $m_no_2s = $_POST['m_no_2'] ?? [];
    $cushions = $_POST['cushion'] ?? [];
    $end_2s = $_POST['end_2'] ?? [];
    $m_no_3s = $_POST['m_no_3'] ?? [];
    $treads = $_POST['tread'] ?? [];
    $width_2s = $_POST['width_2'] ?? [];
    $diam_2s = $_POST['diam_2'] ?? [];
    $end_time_2s = $_POST['end_time_2'] ?? [];
    $curing_start_times = $_POST['curing_start_time'] ?? [];
    $press_nos = $_POST['press_no'] ?? [];

    // Insert each row into tire_production_f table
    for ($i = 0; $i < count($serialNumbers); $i++) {
        if (empty($serialNumbers[$i])) continue; // Skip empty rows

        $serialNumber = $conn->real_escape_string($serialNumbers[$i]);
        $tyre_size = $conn->real_escape_string($tyre_sizes[$i] ?? '');
        $brand = $conn->real_escape_string($brands[$i] ?? '');
        $m_no_1 = $conn->real_escape_string($m_no_1s[$i] ?? '');
        $temp = $conn->real_escape_string($temps[$i] ?? '');
        $width_1 = $conn->real_escape_string($width_1s[$i] ?? '');
        $diam = $conn->real_escape_string($diams[$i] ?? '');
        $end_time_1 = $conn->real_escape_string($end_time_1s[$i] ?? '');
        $m_no_2 = $conn->real_escape_string($m_no_2s[$i] ?? '');
        $cushion = $conn->real_escape_string($cushions[$i] ?? '');
        $end_2 = $conn->real_escape_string($end_2s[$i] ?? '');
        $m_no_3 = $conn->real_escape_string($m_no_3s[$i] ?? '');
        $tread = $conn->real_escape_string($treads[$i] ?? '');
        $width_2 = $conn->real_escape_string($width_2s[$i] ?? '');
        $diam_2 = $conn->real_escape_string($diam_2s[$i] ?? '');
        $end_time_2 = $conn->real_escape_string($end_time_2s[$i] ?? '');
        $curing_start_time = $conn->real_escape_string($curing_start_times[$i] ?? '');
        $press_no = $conn->real_escape_string($press_nos[$i] ?? '');

        $insertQuery = "INSERT INTO tire_production_f (
            date, shift_time, serialNumber, tyre_size, brand, m_no_1, temp, width_1, diam, end_time_1,
            m_no_2, cushion, end_2, m_no_3, tread, width_2, diam_2, end_time_2, curing_start_time, press_no, employee_id
        ) VALUES (
            '$date', '$shift_time', '$serialNumber', '$tyre_size', '$brand', '$m_no_1', '$temp', '$width_1', '$diam', '$end_time_1',
            '$m_no_2', '$cushion', '$end_2', '$m_no_3', '$tread', '$width_2', '$diam_2', '$end_time_2', '$curing_start_time', '$press_no', '$employee_id'
        )";

        if (!$conn->query($insertQuery)) {
            die("Insert query failed: " . $conn->error);
        }
    }

    // Set a success message in the session
    $_SESSION['success_message'] = "Production records added successfully!";
    // Redirect to the same page to prevent resubmission
    header("Location: green_tire.php");
    exit();
}

// Fetch serial numbers for dropdown
$serialNumbersQuery = "SELECT serialNumber, brand FROM tire_data";
$serialNumbersResult = $conn->query($serialNumbersQuery);
if ($serialNumbersResult === false) {
    die("Query failed (serialNumbersQuery): " . $conn->error);
}

// Fetch employee IDs
$employeeQuery = "SELECT DISTINCT employee_id FROM employees ORDER BY employee_id";
$employeeResult = $conn->query($employeeQuery);
if ($employeeResult === false) {
    $employeeResult = $conn->query("SELECT DISTINCT employee_id FROM tire_inspections ORDER BY employee_id");
}

// Fetch submitted data for display
$submittedDataQuery = "SELECT date, shift_time, serialNumber, tyre_size, brand, m_no_1, temp, width_1, diam, end_time_1,
    m_no_2, cushion, end_2, m_no_3, tread, width_2, diam_2, end_time_2, curing_start_time, press_no
    FROM tire_production_f ORDER BY created_at DESC";
$submittedDataResult = $conn->query($submittedDataQuery);
if ($submittedDataResult === false) {
    die("Query failed (submittedDataQuery): " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tire Inspection System</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            background-color: #e9ecef;
            color: #333;
        }
        .container {
            max-width: 1400px;
            margin: 20px auto;
            background: #ffffff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        .header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding-bottom: 20px;
            border-bottom: 1px solid #dee2e6;
        }
        .header img {
            height: 60px;
        }
        .header h2 {
            margin: 0;
            font-size: 1.8em;
            color: #212529;
        }
        h1 {
            font-size: 1.8em;
            text-align: center;
            color: #212529;
            margin: 20px 0;
            font-weight: 700;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-row {
            display: flex;
            gap: 20px;
            align-items: flex-start;
        }
        .form-row .form-group {
            flex: 1;
            margin-bottom: 0;
        }
        label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: #495057;
        }
        select, input[type="text"], input[list], input[type="date"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ced4da;
            border-radius: 6px;
            font-size: 1em;
            transition: border-color 0.3s, box-shadow 0.3s;
        }
        select:focus, input[type="text"]:focus, input[list]:focus, input[type="date"]:focus {
            border-color: #F28018;
            box-shadow: 0 0 5px #F28018;
            outline: none;
        }
        input[type="text"], input[type="date"] {
            height: 30px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: #ffffff;
            font-size: 0.75em;
        }
        th, td {
            padding: 6px 8px;
            text-align: center;
            border: 1px solid #dee2e6;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        th {
            background-color: rgb(7, 7, 7);
            color: #ffffff;
            font-weight: 600;
            font-size: 0.7em;
            text-transform: uppercase;
        }
        tr:nth-child(even) {
            background-color: #f8f9fa;
        }
        tr:hover {
            background-color: #e9ecef;
        }
        .success-message {
            background-color: #d4edda;
            color: #F28018;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 6px;
            text-align: center;
            font-weight: 500;
        }
        .footer {
            margin-top: 30px;
            font-size: 0.9em;
            color: #6c757d;
            text-align: center;
        }
        #production-table th {
            font-size: 0.65em;
        }
        #production-table input[type="text"], #production-table select {
            padding: 4px;
            font-size: 0.8em;
            height: 25px;
        }
        .action-button {
            background-color: #F28018;
            color: #ffffff;
            padding: 8px 16px;
            border: none;
            border-radius: 6px;
            font-size: 1em;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.2s;
            margin: 10px 0;
        }
        .action-button:hover {
            background-color: #F28018;
            transform: translateY(-2px);
        }
        input[type="submit"] {
            background-color: rgb(4, 4, 4);
            color: #ffffff;
            padding: 12px 24px;
            border: none;
            border-radius: 6px;
            font-size: 1.1em;
            cursor: pointer;
            transition: background-color 0.3s, transform 0.2s;
        }
        input[type="submit"]:hover {
            background-color: rgb(10, 10, 10);
            transform: translateY(-2px);
        }
        .remove-button {
            background-color: rgb(10, 9, 9);
            color: #ffffff;
            padding: 4px 8px;
            border: none;
            border-radius: 4px;
            font-size: 0.9em;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .remove-button:hover {
            background-color: rgb(10, 10, 10);
        }
        /* Styling for grouped headers */
        .category-header {
            background-color: rgb(4, 4, 4);
            font-size: 0.8em;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <img src="https://cdn.prod.website-files.com/64f8065a81be9734043da10e/64f818f083a1ce0044ce06a4_ATIRE-logo.png" alt="ATIRE Logo">
        </div>

        <!-- Display success message if set -->
        <?php if (isset($_SESSION['success_message'])): ?>
            <div class="success-message">
                <?php echo $_SESSION['success_message']; ?>
                <?php unset($_SESSION['success_message']); ?>
            </div>
        <?php endif; ?>

        <!-- Add New Section -->
        <h1>GREEN TYRE BUILDING CHECK LIST</h1>
        <form method="POST" action="">
            <div class="form-row">
                <div class="form-group">
                    <label for="date">Date:</label>
                    <input type="date" name="date" id="date" required>
                </div>
                <div class="form-group">
                    <label for="shift_time">Shift Time:</label>
                    <select name="shift_time" id="shift_time" required>
                        <option value="">Select Shift</option>
                        <option value="Day A">Day A</option>
                        <option value="Day B">Day B</option>
                        <option value="Day C">Day C</option>
                        <option value="Night A">Night A</option>
                        <option value="Night B">Night B</option>
                        <option value="Night C">Night C</option>
                    </select>
                </div>
            </div>

            <table id="production-table">
                <thead>
                    <tr>
                        <th rowspan="2">No.</th>
                        <th rowspan="2">Serial No.</th>
                        <th rowspan="2">Tyre Size</th>
                        <th rowspan="2">Brand</th>
                        <th colspan="5" class="category-header">Base</th>
                        <th colspan="3" class="category-header">Cushion</th>
                        <th colspan="5" class="category-header">Tread</th>
                        <th rowspan="2">Curing Start Time</th>
                        <th rowspan="2">Press No.</th>
                        <th rowspan="2">Action</th>
                    </tr>
                    <tr>
                        <th>M.No.</th>
                        <th>Temp</th>
                        <th>Width</th>
                        <th>Diam</th>
                        <th>End Time</th>
                        <th>M.No.</th>
                        <th>Cushion</th>
                        <th>End</th>
                        <th>M.No.</th>
                        <th>Tread</th>
                        <th>Width</th>
                        <th>Diam</th>
                        <th>End Time</th>
                    </tr>
                </thead>
                <tbody id="production-table-body">
                    <tr>
                        <td>1</td>
                        <td>
                            <select name="serialNumber[]" onchange="updateBrand(this, 0)">
                                <option value="">Select Serial Number</option>
                                <?php 
                                $serialNumbersResult->data_seek(0); 
                                while ($row = $serialNumbersResult->fetch_assoc()): ?>
                                    <option value="<?php echo $row['serialNumber']; ?>" 
                                            data-brand="<?php echo $row['brand']; ?>">
                                        <?php echo $row['serialNumber']; ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </td>
                        <td><input type="text" name="tyre_size[]"></td>
                        <td><input type="text" name="brand[]" class="brand-input" readonly></td>
                        <!-- Base -->
                        <td><input type="text" name="m_no_1[]"></td>
                        <td><input type="text" name="temp[]"></td>
                        <td><input type="text" name="width_1[]"></td>
                        <td><input type="text" name="diam[]"></td>
                        <td><input type="text" name="end_time_1[]"></td>
                        <!-- Cushion -->
                        <td><input type="text" name="m_no_2[]"></td>
                        <td><input type="text" name="cushion[]"></td>
                        <td><input type="text" name="end_2[]"></td>
                        <!-- Tread -->
                        <td><input type="text" name="m_no_3[]"></td>
                        <td><input type="text" name="tread[]"></td>
                        <td><input type="text" name="width_2[]"></td>
                        <td><input type="text" name="diam_2[]"></td>
                        <td><input type="text" name="end_time_2[]"></td>
                        <!-- Curing Start Time and Press No. -->
                        <td><input type="text" name="curing_start_time[]"></td>
                        <td><input type="text" name="press_no[]"></td>
                        <td><button type="button" class="remove-button" onclick="removeRow(this)">Remove</button></td>
                    </tr>
                </tbody>
            </table>

            <button type="button" class="action-button" onclick="addTableRow()">Add New Row</button>

            <div class="form-group">
                <label for="employee_id">Employee ID:</label>
                <input list="employee_ids" name="employee_id" id="employee_id" required>
                <datalist id="employee_ids">
                    <?php 
                    if ($employeeResult) $employeeResult->data_seek(0); 
                    while ($employeeResult && $row = $employeeResult->fetch_assoc()): ?>
                        <option value="<?php echo $row['employee_id']; ?>">
                    <?php endwhile; ?>
                </datalist>
            </div>

            <input type="submit" name="submit_inspection" value="Submit Production Data">
        </form>

        <!-- Display Submitted Data -->
        <h1>Submitted Production Data</h1>
        <table>
            <thead>
                <tr>
                    <th rowspan="2">Date</th>
                    <th rowspan="2">Shift Time</th>
                    <th rowspan="2">Serial No.</th>
                    <th rowspan="2">Tyre Size</th>
                    <th rowspan="2">Brand</th>
                    <th colspan="5" class="category-header">Base</th>
                    <th colspan="3" class="category-header">Cushion</th>
                    <th colspan="5" class="category-header">Tread</th>
                    <th rowspan="2">Curing Start Time</th>
                    <th rowspan="2">Press No.</th>
                </tr>
                <tr>
                    <th>M.No.</th>
                    <th>Temp</th>
                    <th>Width</th>
                    <th>Diam</th>
                    <th>End Time</th>
                    <th>M.No.</th>
                    <th>Cushion</th>
                    <th>End</th>
                    <th>M.No.</th>
                    <th>Tread</th>
                    <th>Width</th>
                    <th>Diam</th>
                    <th>End Time</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $submittedDataResult->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['date'] ?: '-'; ?></td>
                        <td><?php echo $row['shift_time'] ?: '-'; ?></td>
                        <td><?php echo $row['serialNumber'] ?: '-'; ?></td>
                        <td><?php echo $row['tyre_size'] ?: '-'; ?></td>
                        <td><?php echo $row['brand'] ?: '-'; ?></td>
                        <!-- Base -->
                        <td><?php echo $row['m_no_1'] ?: '-'; ?></td>
                        <td><?php echo $row['temp'] ?: '-'; ?></td>
                        <td><?php echo $row['width_1'] ?: '-'; ?></td>
                        <td><?php echo $row['diam'] ?: '-'; ?></td>
                        <td><?php echo $row['end_time_1'] ?: '-'; ?></td>
                        <!-- Cushion -->
                        <td><?php echo $row['m_no_2'] ?: '-'; ?></td>
                        <td><?php echo $row['cushion'] ?: '-'; ?></td>
                        <td><?php echo $row['end_2'] ?: '-'; ?></td>
                        <!-- Tread -->
                        <td><?php echo $row['m_no_3'] ?: '-'; ?></td>
                        <td><?php echo $row['tread'] ?: '-'; ?></td>
                        <td><?php echo $row['width_2'] ?: '-'; ?></td>
                        <td><?php echo $row['diam_2'] ?: '-'; ?></td>
                        <td><?php echo $row['end_time_2'] ?: '-'; ?></td>
                        <!-- Curing Start Time and Press No. -->
                        <td><?php echo $row['curing_start_time'] ?: '-'; ?></td>
                        <td><?php echo $row['press_no'] ?: '-'; ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>

        <div class="footer">
            © <?php echo date('Y'); ?> ATIRE. All rights reserved.
        </div>
    </div>

    <script>
        let rowCount = 1;

        function updateBrand(selectElement, rowIndex) {
            const brandInput = document.querySelector(`#production-table-body tr:nth-child(${rowIndex + 1}) .brand-input`);
            const selectedOption = selectElement.options[selectElement.selectedIndex];
            brandInput.value = selectedOption.dataset.brand || '';
        }

        function addTableRow() {
            rowCount++;
            const tbody = document.getElementById('production-table-body');
            const newRow = document.createElement('tr');
            newRow.innerHTML = `
                <td>${rowCount}</td>
                <td>
                    <select name="serialNumber[]" onchange="updateBrand(this, ${rowCount - 1})">
                        <option value="">Select Serial Number</option>
                        <?php 
                        $serialNumbersResult->data_seek(0); 
                        while ($row = $serialNumbersResult->fetch_assoc()): ?>
                            <option value="<?php echo $row['serialNumber']; ?>" 
                                    data-brand="<?php echo $row['brand']; ?>">
                                <?php echo $row['serialNumber']; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </td>
                <td><input type="text" name="tyre_size[]"></td>
                <td><input type="text" name="brand[]" class="brand-input" readonly></td>
                <!-- Base -->
                <td><input type="text" name="m_no_1[]"></td>
                <td><input type="text" name="temp[]"></td>
                <td><input type="text" name="width_1[]"></td>
                <td><input type="text" name="diam[]"></td>
                <td><input type="text" name="end_time_1[]"></td>
                <!-- Cushion -->
                <td><input type="text" name="m_no_2[]"></td>
                <td><input type="text" name="cushion[]"></td>
                <td><input type="text" name="end_2[]"></td>
                <!-- Tread -->
                <td><input type="text" name="m_no_3[]"></td>
                <td><input type="text" name="tread[]"></td>
                <td><input type="text" name="width_2[]"></td>
                <td><input type="text" name="diam_2[]"></td>
                <td><input type="text" name="end_time_2[]"></td>
                <!-- Curing Start Time and Press No. -->
                <td><input type="text" name="curing_start_time[]"></td>
                <td><input type="text" name="press_no[]"></td>
                <td><button type="button" class="remove-button" onclick="removeRow(this)">Remove</button></td>
            `;
            tbody.appendChild(newRow);
        }

        function removeRow(button) {
            const row = button.closest('tr');
            row.remove();
            // Update row numbers
            const rows = document.querySelectorAll('#production-table-body tr');
            rows.forEach((row, index) => {
                row.cells[0].textContent = index + 1;
            });
            rowCount = rows.length;
        }
    </script>
</body>
</html>

<?php $conn->close(); ?>