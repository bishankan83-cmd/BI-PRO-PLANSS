<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start session to store success message
session_start();

// Database connection
$servername = "localhost";
$username = "planatir_task_managemen";
$password = "Bishan@1919";
$dbname = "planatir_task_managemen";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_inspection'])) {
    $serialNumber = $conn->real_escape_string($_POST['serialNumber']);
    $pattern = isset($_POST['pattern']) ? $conn->real_escape_string($_POST['pattern']) : '';
    $h1 = isset($_POST['h1']) ? $conn->real_escape_string($_POST['h1']) : '';
    $h2 = isset($_POST['h2']) ? $conn->real_escape_string($_POST['h2']) : '';
    $h3 = isset($_POST['h3']) ? $conn->real_escape_string($_POST['h3']) : '';
    $h4 = isset($_POST['h4']) ? $conn->real_escape_string($_POST['h4']) : '';
    $us1 = isset($_POST['us1']) ? $conn->real_escape_string($_POST['us1']) : '';
    $us2 = isset($_POST['us2']) ? $conn->real_escape_string($_POST['us2']) : '';
    $us3 = isset($_POST['us3']) ? $conn->real_escape_string($_POST['us3']) : '';
    $us4 = isset($_POST['us4']) ? $conn->real_escape_string($_POST['us4']) : '';
    $employee_id = $conn->real_escape_string($_POST['employee_id']);
    $notes = isset($_POST['notes']) ? $conn->real_escape_string($_POST['notes']) : '';

    // Fetch brand based on serial number
    $brandQuery = "SELECT brand FROM tire_data WHERE serialNumber = '$serialNumber'";
    $brandResult = $conn->query($brandQuery);
    if ($brandResult === false) {
        die("Query failed (brandQuery): " . $conn->error);
    }
    $brand = $brandResult->fetch_assoc()['brand'] ?? '';

    // Prepare defect data
    $defects = [
        'back_rind', 'bead_wire_exposed', 'damage_contour', 'deformed_tread_bloc',
        'double_molding', 'flow_marks', 'foriegn_material', 'nm_flow_clip',
        'mold_out_of_line', 'side_wall_open_black', 'black_mix', 'peel', 'base_flow_marks',
        'cure_flash', 'band_edge_cushion', 'band_seperate'
    ];

    $values = [];
    foreach ($defects as $defect) {
        $values[$defect] = isset($_POST[$defect]) ? 1 : 0;
    }

    // Insert into tire_inspections table
    $insertQuery = "INSERT INTO tire_defect_nm (
        serialNumber, brand, pattern, h1, h2, h3, h4, us1, us2, us3, us4, employee_id, notes, " . implode(',', $defects) . "
    ) VALUES (
        '$serialNumber', '$brand', '$pattern', '$h1', '$h2', '$h3', '$h4', '$us1', '$us2', '$us3', '$us4', '$employee_id', '$notes', " . implode(',', array_values($values)) . "
    )";

    if ($conn->query($insertQuery)) {
        // Set a success message in the session
        $_SESSION['success_message'] = "Record added successfully!";
        // Redirect to the same page to prevent resubmission
        header("Location: daily_defect_nm_nm.php");
        exit();
    } else {
        die("Insert query failed: " . $conn->error);
    }
}

// Fetch serial numbers for dropdown
$serialNumbersQuery = "SELECT serialNumber, brand FROM tire_data";
$serialNumbersResult = $conn->query($serialNumbersQuery);
if ($serialNumbersResult === false) {
    die("Query failed (serialNumbersQuery): " . $conn->error);
}

// Fetch employee IDs for datalist
$employeeQuery = "SELECT DISTINCT employee_id FROM tire_defect_nm";
$employeeResult = $conn->query($employeeQuery);
if ($employeeResult === false) {
    die("Query failed (employeeQuery): " . $conn->error);
}

// Define defects array with labels
$defects = [
    'back_rind' => 'Back Rind',
    'bead_wire_exposed' => 'Bead Wire Exposed',
    'damage_contour' => 'Damage Contour',
    'deformed_tread_bloc' => 'Deformed Tread Bloc',
    'double_molding' => 'Double Molding',
    'flow_marks' => 'Flow Marks',
    'foriegn_material' => 'Foreign Material',
    'nm_flow_clip' => 'NM Flow Clip',
    'mold_out_of_line' => 'Mold Out of Line',
    'side_wall_open_black' => 'Side Wall Open Black',
    'black_mix' => 'Black Mix',
    'peel' => 'Peel',
    'base_flow_marks' => 'Base Flow Marks',
    'cure_flash' => 'Cure Flash',
    'band_edge_cushion' => 'Band Edge Cushion',
    'band_seperate' => 'Band Separate'
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ATIRE - Tire Inspection System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <style>
        :root {
            --primary: #F28018;
            --secondary: #212529;
            --success: #28a745;
            --danger: #dc3545;
            --warning: #ffc107;
            --info: #17a2b8;
            --light: #f8f9fa;
            --dark: #343a40;
            --gray: #6c757d;
            --border: #dee2e6;
        }
        
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f7fa;
            color: var(--secondary);
            line-height: 1.6;
        }
        
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 0 15px;
        }
        
        .header {
            background-color: #fff;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }
        
        .header-content {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 15px 0;
        }
        
        .logo {
            height: 50px;
        }
        
        .app-title {
            font-size: 20px;
            font-weight: 600;
            color: var(--secondary);
        }
        
        .main {
            padding: 30px 0;
        }
        
        .card {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            padding: 25px;
            margin-bottom: 30px;
        }
        
        .card-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 20px;
            color: var(--secondary);
            display: flex;
            align-items: center;
        }
        
        .card-title i {
            margin-right: 10px;
            color: var(--primary);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-row {
            display: flex;
            flex-wrap: wrap;
            margin: 0 -10px;
        }
        
        .form-col {
            flex: 1;
            padding: 0 10px;
            min-width: 250px;
        }
        
        .form-label {
            display: block;
            font-weight: 600;
            margin-bottom: 8px;
            color: var(--secondary);
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid var(--border);
            border-radius: 6px;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(242, 128, 24, 0.25);
            outline: none;
        }
        
        .form-control:disabled,
        .form-control[readonly] {
            background-color: #f8f9fa;
            opacity: 0.7;
        }
        
        .defects-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 10px;
        }
        
        .defect-item {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 15px;
            border-radius: 6px;
            transition: all 0.3s ease;
            border: 1px solid var(--border);
        }
        
        .defect-item:hover {
            background-color: rgba(242, 128, 24, 0.05);
            border-color: var(--primary);
        }
        
        .form-check {
            width: 18px;
            height: 18px;
            accent-color: var(--primary);
        }
        
        .btn {
            display: inline-block;
            font-weight: 600;
            text-align: center;
            white-space: nowrap;
            vertical-align: middle;
            user-select: none;
            border: 1px solid transparent;
            padding: 12px 25px;
            font-size: 14px;
            line-height: 1.5;
            border-radius: 6px;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .btn-primary {
            color: #fff;
            background-color: var(--primary);
            border-color: var(--primary);
        }
        
        .btn-primary:hover {
            background-color: #dd7016;
            border-color: #dd7016;
        }
        
        .btn-secondary {
            color: #fff;
            background-color: var(--secondary);
            border-color: var(--secondary);
        }
        
        .btn-secondary:hover {
            background-color: #16181b;
            border-color: #16181b;
        }
        
        .form-actions {
            display: flex;
            justify-content: flex-end;
            gap: 15px;
            margin-top: 30px;
        }
        
        .alert {
            padding: 15px 20px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 6px;
        }
        
        .alert-success {
            color: #155724;
            background-color: #d4edda;
            border-color: #c3e6cb;
        }
        
        .hardness-us-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
            gap: 15px;
            margin-top: 10px;
        }
        
        .hardness-us-item {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        
        .hardness-us-label {
            font-weight: 600;
            color: var(--secondary);
            font-size: 14px;
        }
        
        .footer {
            background-color: #fff;
            box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.05);
            padding: 20px 0;
            text-align: center;
            margin-top: 50px;
        }
        
        .footer-text {
            font-size: 14px;
            color: var(--gray);
        }
        
        @media (max-width: 768px) {
            .form-row {
                flex-direction: column;
            }
            
            .form-col {
                width: 100%;
            }
            
            .defects-grid {
                grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            }
            
            .form-actions {
                flex-direction: column;
            }
            
            .btn {
                width: 100%;
                margin-bottom: 10px;
            }
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="header-content">
                <img src="https://cdn.prod.website-files.com/64f8065a81be9734043da10e/64f818f083a1ce0044ce06a4_ATIRE-logo.png" alt="ATIRE Logo" class="logo">
                <div class="app-title">Tire Inspection System</div>
            </div>
        </div>
    </header>

    <main class="main">
        <div class="container">
            <!-- Display success message if set -->
            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $_SESSION['success_message']; ?>
                </div>
                <?php unset($_SESSION['success_message']); ?>
            <?php endif; ?>

            <!-- Add New Section -->
            <div class="card">
                <div class="card-title">
                    <i class="fas fa-exclamation-triangle"></i> Register Defected Tire
                </div>
                <form method="POST" action="">
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="serialNumber" class="form-label">Serial Number</label>
                                <select name="serialNumber" id="serialNumber" class="form-control" required onchange="updateBrand()">
                                    <option value="">Select Serial Number</option>
                                    <?php 
                                    // Reset result set pointer
                                    $serialNumbersResult->data_seek(0); 
                                    while ($row = $serialNumbersResult->fetch_assoc()): ?>
                                        <option value="<?php echo $row['serialNumber']; ?>" 
                                                data-brand="<?php echo $row['brand']; ?>">
                                            <?php echo $row['serialNumber']; ?>
                                        </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="brand" class="form-label">Brand</label>
                                <input type="text" id="brand" class="form-control" readonly>
                            </div>
                        </div>
                        <div class="form-col">
                            <div class="form-group">
                                <label for="pattern" class="form-label">Pattern</label>
                                <input type="text" name="pattern" id="pattern" class="form-control" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="employee_id" class="form-label">Employee ID</label>
                                <input list="employee_ids" name="employee_id" id="employee_id" class="form-control" required>
                                <datalist id="employee_ids">
                                    <?php 
                                    // Reset result set pointer
                                    if ($employeeResult) $employeeResult->data_seek(0); 
                                    while ($employeeResult && $row = $employeeResult->fetch_assoc()): ?>
                                        <option value="<?php echo $row['employee_id']; ?>">
                                    <?php endwhile; ?>
                                </datalist>
                            </div>
                        </div>
                    </div>

                    <div class="card" style="box-shadow: none; padding: 15px 0;">
                        <div class="card-title">
                            <i class="fas fa-sliders-h"></i> Measurements
                        </div>
                        <div class="form-row">
                            <div class="form-col">
                                <div class="form-group">
                                    <label class="form-label">Hardness Readings</label>
                                    <div class="hardness-us-grid">
                                        <div class="hardness-us-item">
                                            <label class="hardness-us-label">H1</label>
                                            <input type="text" name="h1" class="form-control" placeholder="Reading">
                                        </div>
                                        <div class="hardness-us-item">
                                            <label class="hardness-us-label">H2</label>
                                            <input type="text" name="h2" class="form-control" placeholder="Reading">
                                        </div>
                                        <div class="hardness-us-item">
                                            <label class="hardness-us-label">H3</label>
                                            <input type="text" name="h3" class="form-control" placeholder="Reading">
                                        </div>
                                        <div class="hardness-us-item">
                                            <label class="hardness-us-label">H4</label>
                                            <input type="text" name="h4" class="form-control" placeholder="Reading">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-col">
                                <div class="form-group">
                                    <label class="form-label">Ultrasonic Readings</label>
                                    <div class="hardness-us-grid">
                                        <div class="hardness-us-item">
                                            <label class="hardness-us-label">US1</label>
                                            <input type="text" name="us1" class="form-control" placeholder="Reading">
                                        </div>
                                        <div class="hardness-us-item">
                                            <label class="hardness-us-label">US2</label>
                                            <input type="text" name="us2" class="form-control" placeholder="Reading">
                                        </div>
                                        <div class="hardness-us-item">
                                            <label class="hardness-us-label">US3</label>
                                            <input type="text" name="us3" class="form-control" placeholder="Reading">
                                        </div>
                                        <div class="hardness-us-item">
                                            <label class="hardness-us-label">US4</label>
                                            <input type="text" name="us4" class="form-control" placeholder="Reading">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="card" style="box-shadow: none; padding: 15px 0;">
                        <div class="card-title">
                            <i class="fas fa-bug"></i> Defect Types
                        </div>
                        <div class="defects-grid">
                            <?php foreach ($defects as $key => $label): ?>
                            <div class="defect-item">
                                <input type="checkbox" name="<?php echo $key; ?>" id="<?php echo $key; ?>" class="form-check">
                                <label for="<?php echo $key; ?>"><?php echo $label; ?></label>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="notes" class="form-label">Notes</label>
                        <textarea name="notes" id="notes" class="form-control" rows="3" placeholder="Additional observations or notes"></textarea>
                    </div>

                    <div class="form-actions">
                        <button type="reset" class="btn btn-secondary">
                            <i class="fas fa-undo"></i> Reset
                        </button>
                        <button type="submit" name="submit_inspection" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Record
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <footer class="footer">
        <div class="container">
            <div class="footer-text">
                &copy; <?php echo date('Y'); ?> ATIRE Tire Inspection System. All Rights Reserved.
            </div>
        </div>
    </footer>

    <script>
        // Function to update brand based on selected serial number
        function updateBrand() {
            const serialNumberSelect = document.getElementById('serialNumber');
            const brandInput = document.getElementById('brand');
            
            if (serialNumberSelect.selectedIndex > 0) {
                const selectedOption = serialNumberSelect.options[serialNumberSelect.selectedIndex];
                brandInput.value = selectedOption.getAttribute('data-brand');
            } else {
                brandInput.value = '';
            }
        }
    </script>
</body>
</html>